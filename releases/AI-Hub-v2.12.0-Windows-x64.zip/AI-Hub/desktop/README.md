# AI Hub 桌面入口

`AI Hub.exe` 是 Windows x64 图形应用，使用深色 WinForms 窗口承载现有 WebView2 工作台。后台仍是现有 Python 标准库服务，页面和数据与浏览器入口共用。

## 日常运行

双击解压目录中的 AI Hub.exe，也可以为它创建桌面快捷方式。EXE 必须与 `server.py`、`launcher.pyw`、`frontend` 同级；移动整个项目目录后重新建立快捷方式即可。开发测试可以指定 `--root "程序目录"`。程序不申请管理员权限，不配置开机启动。

重复运行会恢复并激活同一程序目录的已有窗口。窗口右上角的关闭按钮将工作台安静隐藏到系统托盘，不弹常规后台通知，保留页面状态、共享后台服务及扫描任务。托盘使用曜核金色眼图标；Windows 可能将其收进任务栏的隐藏图标区。

- 双击托盘图标或右键选择“打开曜核”，恢复工作台。
- 页面启动失败时，右键选择“重试打开工作台”；缺少 WebView2 时也保留托盘退出入口。
- 右键选择“软件更新…”打开原生更新窗体，可检查候选版、下载并验证、设置自动检查与自动安装；网页只可请求打开这个窗体，更新操作仍由桌面端发起。
- 右键选择“退出曜核（含后台）”，会验证本安装的服务身份并请求安全关闭。确认后台停止后才移除托盘并退出桌面程序。
- 后台仍在处理任务或状态无法确认时，保留托盘并提示稍后重试；不强制结束扫描、其他应用或任意 PID。旧版后台不支持安全退出协议时，需先结束旧版后台再启动新版。
- 自动检查默认开启，自动安装默认关闭。开启后，更新包会在后台下载并验证；只有通过托盘显式选择“退出曜核”时才应用就绪更新，X 和 Windows 注销/关机不会触发更新。自动安装随正常退出关闭应用，不会重启。
- “安装并重启”会先检查页面未保存状态；存在未保存编辑时需要再次明确确认，无法确认时停止手动安装。桌面通过受控本机 API 准备事务，并启动本机已安装的独立更新助手。
- Windows 注销或关机不会被托盘隐藏行为阻止。

2.11.3 在窗口出现后、服务和工作台页面真实就绪前，显示以完整 E01 金眼图标为中心的原生等待场景：柔和靛金光晕、两层细环与缓慢移动的弧线、10 枚低亮汇聚光点及短拖尾。场景按约 400 px 设计，中心图标 144 px，随 DPI 和小窗口整体缩放；首帧即有完整层次。不显示“正在打开/正在加载”文字或进度条。页面导航完成后立即移除场景，不设置最短展示时间，不等待动效播放完毕，也不增加开场页面。启动失败仍显示原错误说明和重试入口。

动画使用已有嵌入图标，静态柔光只缓存一次，33 ms 定时器只重绘有界的中央场景；不逐帧分配大位图。窗口隐藏、最小化、开始退出或加载完成时停表。恢复窗口只在尚未完成加载时继续，正常工作台不会重播。Windows 动画效果关闭或偏好无法读取时显示完整静态构图；设置变化立即生效。控件释放时停表、解除 Tick 事件并释放图标、柔光和绘图资源。

后台端口沿用 `data/config.json`，只连接 `127.0.0.1`。网页来源链接交给默认浏览器；桌面窗口只加载本地工作台。不添加开机启动。

主机需要 Python 3.9+、.NET Framework 4.8+、Microsoft Edge WebView2 Runtime。EXE 包含 WebView2 Core、WinForms 与 x64 Loader 三个 SDK 组件，首次启动在程序的 data/desktop 目录释放经摘要校验的 Loader。它不包含 Python、本机模型和资产数据库；请保留整个程序目录与 Python 安装。

`data/desktop.log` 记录窗口与服务启动结果。窗口尺寸、收藏、WebView2 配置和嵌入 Loader 统一存放在项目 `data/desktop`。这样从资源管理器或打包的开发工具启动时也使用同一配置，避免 LocalAppData 虚拟化形成两份状态。评分、备注、来源仍在项目 `data`；外部普通浏览器收藏不自动迁入。

启动器通过目录句柄解析联接的物理路径，再生成单实例标识。多个目录联接入口共用同一窗口和 data。

## 可复现构建

不安装 pip、npm 或 Visual Studio。使用 Windows 自带的 .NET Framework C# 编译器。先手动取得微软官方 SDK 归档，构建脚本只读取本地包并验证摘要，不联网下载。

```powershell
python -B desktop/build.py --sdk-package "下载目录/microsoft.web.webview2.1.0.4191.47.nupkg" --output "临时目录/AI Hub.exe" --test
```

SDK 版本：`1.0.4191.47`。官方 nupkg：9,259,926 字节（8.83 MiB）。SHA-256：`f492bbf547d0da329553b6727435b677579b1e9f91cc9e4a1ad029366d5f23d0`。

构建参数为 `target:winexe`、`platform:x64`，程序集版本 `2.12.0.0`，包含图标与 asInvoker / PerMonitorV2 清单。测试覆盖配置、端口边界、网页更新请求来源、Windows 参数转义、服务身份、带身份校验的退出请求、忙碌拒绝、启动回执、晚启动进程退出、PID 重用隔离、真实 Python 冷启动与无控制台进程。冷启动只使用独立临时夹与自退测试服务，不重启用户服务。另有原生加载控件的无窗口生命周期与离屏场景绘制检查，覆盖隐藏、最小化、减少动画、完成、重试、DPI、小尺寸、绘制边界和 GDI 对象释放。构建附加 `--render-output "临时帧目录"` 可输出 t=0/0.6/1.8 秒、减少动画及小尺寸的源码控件合成 PNG；`--update-render-output "更新窗体.png"` 保存原生更新窗体的离屏布局预览。这些是离屏合成检查，不能作为真实启动耗时或 CPU 测量，也不替代真实托盘菜单、WebView 消息、更新窗体点击和系统注销验收。

更新事务由本机服务准备，并在受控退出后由独立 helper 校验并逐文件替换；helper 不会强杀进程，也会在启动锁或忙碌检查失败时保留当前程序。桌面端只发送固定本机 API 操作与固定消息，不接收页面给出的 URL、命令或包路径。应用数据位于 `data/`，更新事务保存在 `data/app-updates/`。

原生入口在取得桌面互斥锁前后检查更新事务，活事务期间再次打开会安静退出，避免阻挡安装；失效事务仍交由现有启动恢复流程处理。`--test` 会用本次构建的真实 EXE 验证活事务、Python 字节锁与中断恢复。可附加 `--startup-guard-candidate "最终解压目录/AI Hub.exe"`，针对已有最终 EXE 重跑启动保护夹具；所有夹具使用临时目录和隔离端口。

安全退出控制文件 `data/desktop/server-control.json` 只用于当前本机服务实例，包含每次启动生成的随机令牌，不写入日志或发行包。桌面启动专属回执使用随机文件名、排他新建，读取后清理；超时后仅查询本次子进程的创建时间和退出状态，不执行进程终止。

组件来源与实现参考：

- [Microsoft 官方 SDK 包](https://www.nuget.org/packages/Microsoft.Web.WebView2/1.0.4191.47)
- [WebView2 WinForms 指南](https://learn.microsoft.com/en-us/microsoft-edge/webview2/get-started/winforms)
- [WebView2 分发说明](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/distribution)
- [WebView2 安全实践](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/security)
- [Windows 客户区动画偏好](https://learn.microsoft.com/en-us/windows/win32/winauto/client-area-animation)
- [WM_SETTINGCHANGE](https://learn.microsoft.com/en-us/windows/win32/winmsg/wm-settingchange)

SDK 许可全文见 `WebView2-LICENSE.txt`，同时嵌入 EXE。

开发机如已缓存 SDK，可以直接传给 `--sdk-package`。公开源码包不包含 SDK 缓存；Windows 桌面包中的 EXE 已包含运行所需的三个 SDK 组件。
