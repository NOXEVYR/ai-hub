# -*- coding: utf-8 -*-
"""文件系统扫描：目录/文件清单 + 模型识别 + codex 目录(00_Management/Catalogs)导入。"""
import csv
import json
import os
import re
import time

from . import meta, config, classification

# codex 目录 category -> 内部 mtype
CATEGORY_MAP = {
    "Checkpoint": "Checkpoint", "LoRA": "LoRA", "LoRA-Training": "LoRA",
    "Diffusion": "Diffusion", "TextEncoder": "TextEncoder", "VAE": "VAE",
    "ControlNet": "ControlNet", "Embedding": "Embedding", "IPAdapter": "IPAdapter",
    "Vision": "Vision", "Upscaler": "Upscaler", "Speech": "TTS", "Language": "LLM",
    "Topaz": "VideoAI", "ModelPackage": "Package", "PrivateWeight": "Private",
}


# 训练过程状态文件（非资产）：排除出模型库
TRAINING_STATE_RE = re.compile(
    r"^(optimizer|scheduler|random_states|schedules|current_states|lora_weights|"
    r"optimizer_states|step_|snr_|train_state)", re.I)


class ScanSourceError(RuntimeError):
    """A configured scan source cannot be read completely right now."""


def minimal_roots(roots):
    """Return the smallest lexical cover after callers validate every source."""
    unique = {config._key(path): path for path in roots}
    selected = []
    for path in sorted(unique.values(), key=lambda p: (len(p), config._key(p))):
        if not any(config._within(path, parent) for parent in selected):
            selected.append(path)
    return selected


def source_scope(cfg, kind='scan', column='path'):
    """Shared managed-source boundary for views and model actions."""
    if cfg.get('workspace_managed') is not True:
        return '1=1', []
    terms, args, candidates = [], [], set()
    root = cfg.get('ai_root') or ''
    for source in cfg.get(kind + '_roots') or []:
        if not config.scan_root_allowed(source, cfg) or not config._within(source, root):
            continue
        canonical = os.path.realpath(source).rstrip('\\/')
        candidates.add(canonical)
        if kind == 'scan':
            for alias in cfg.get('aliases') or {}:
                if not os.path.isdir(alias):
                    continue
                target = os.path.realpath(alias)
                if config._within(target, canonical):
                    candidates.add(os.path.abspath(alias).rstrip('\\/'))
                elif config._within(canonical, target):
                    candidates.add(os.path.join(alias, os.path.relpath(canonical, target)).rstrip('\\/'))
    for canonical in sorted(candidates):
        prefix = canonical + os.sep
        terms.append(f'({column}=? COLLATE NOCASE OR substr({column},1,?)=? COLLATE NOCASE)')
        args.extend([canonical, len(prefix), prefix])
    return '(' + ' OR '.join(terms) + ')' if terms else '0=1', args


def validate_scan_roots(cfg):
    """Preflight configured sources before a scan can replace the old index."""
    roots = cfg.get("scan_roots", [cfg.get("ai_root")]) or []
    resolved = []
    for root in roots:
        if not config.scan_root_allowed(root, cfg):
            raise ScanSourceError(
                f"扫描来源当前不可用或已被排除：{root}。请恢复该来源，或在来源设置中明确移除。")
        path = os.path.realpath(root)
        try:
            with os.scandir(path):
                pass
        except OSError as exc:
            raise ScanSourceError(f"无法读取扫描来源 {root}：{exc}") from exc
        resolved.append(path)
    return minimal_roots(resolved)


def _strip_extended(p: str) -> str:
    if p.startswith("\\\\?\\UNC\\"):
        return "\\\\" + p[8:]
    if p.startswith("\\\\?\\"):
        return p[4:]
    return p


def _is_reparse_stat(st) -> bool:
    return bool(getattr(st, "st_file_attributes", 0) & 0x400)


def _pref(p):
    """同一文件多入口时选择主展示路径：Library > Runtime > 旧根 > 应用私有。"""
    low = p.lower()
    if "\\library\\" in low:
        return 0
    if "\\runtime\\" in low:
        return 1
    if "\\ai_models\\" in low:
        return 2
    if "\\ai_apps\\" in low:
        return 3
    return 4


def scan_all(db, cfg, progress_cb=None):
    with db.asset_lock:
        return _scan_all(db, cfg, progress_cb)


def _scan_all(db, cfg, progress_cb=None):
    """完整扫描：返回 {file_count, dir_count, model_groups}，并把 files/dirs 写入数据库。"""
    roots = validate_scan_roots(cfg)
    ignore = {name.casefold() for name in (cfg.get("ignore_dirs") or [])}
    dirs_agg = {}          # path -> [size, file_count, dir_count]
    dirs_rows_ignored = [] # 被忽略目录的占位行
    files_rows = []
    groups = {}            # inode -> {paths,size,mtime,ext}
    count = [0]
    seen_inodes = {}       # (dev,ino) -> size，仅模型文件（DirEntry.stat 无 st_ino）
    model_path_bytes = [0]  # 模型文件按路径累加的体积（含硬链接重复）
    model_unique_bytes = [0]  # 模型文件按唯一 inode 的体积
    manual_roles = {classification.path_key(r['model_path']): r['model_role']
                    for r in db.query('SELECT model_path, model_role FROM model_labels')
                    if r['model_role'] in classification.MODEL_ROLES and r['model_role'] != 'Unknown'}
    manual_identities = {identity: role for path, role in manual_roles.items()
                         if (identity := classification.file_identity(path))}

    def report(msg):
        if progress_cb:
            progress_cb(msg)

    def excluded(path):
        try:
            return config.scan_excluded(path, cfg, strict_io=True)
        except OSError as exc:
            raise ScanSourceError(f"读取扫描路径失败 {path}：{exc}") from exc

    def visit(dirpath, depth):
        if excluded(dirpath):
            return
        try:
            entries = list(os.scandir(dirpath))
        except OSError as exc:
            raise ScanSourceError(f"读取扫描目录失败 {dirpath}：{exc}") from exc
        size_acc, f_acc, d_acc = 0, 0, 0
        parent_name = os.path.basename(dirpath)
        for e in entries:
            try:
                st = e.stat(follow_symlinks=False)
            except OSError as exc:
                raise ScanSourceError(f"读取扫描条目失败 {e.path}：{exc}") from exc
            if e.is_symlink() or _is_reparse_stat(st) or excluded(e.path):
                continue
            if e.is_dir(follow_symlinks=False):
                if _is_reparse_stat(st):
                    d_acc += 1  # junction/链接：计入但不深入
                    continue
                if e.name.casefold() in ignore:
                    sub = _strip_extended(e.path)
                    dirs_rows_ignored.append((sub, dirpath, e.name, depth + 1, 0, 0, 0, 1))
                    d_acc += 1
                    continue
                visit(e.path, depth + 1)
                s, f, d = dirs_agg.get(e.path, [0, 0, 0])
                size_acc += s
                f_acc += f
                d_acc += 1 + d
            else:
                path = _strip_extended(e.path)
                ext = os.path.splitext(e.name)[1].lower()
                category, mtype = meta.classify_file(ext, parent_name, path, st.st_size)
                if ext == '.bin' and category != 'model' and manual_roles:
                    role = manual_roles.get(classification.path_key(path)) or manual_identities.get(classification.file_identity(path))
                    if role:
                        category, mtype = 'model', role
                if category == "model":
                    mtype = mtype or meta.model_type(path) or "Unknown"
                if category == "model" and TRAINING_STATE_RE.match(e.name):
                    category = "training"  # 训练状态文件，不入模型库
                ino_key = ""
                if category == "model":
                    try:
                        fst = os.stat(e.path, follow_symlinks=False)  # 完整 stat 才有真实 st_ino
                        ino_key = f"{fst.st_dev}:{fst.st_ino}" if fst.st_ino else "path:" + classification.path_key(path)
                        if ino_key not in seen_inodes:
                            seen_inodes[ino_key] = st.st_size
                            model_unique_bytes[0] += st.st_size
                        model_path_bytes[0] += st.st_size
                        g = groups.setdefault(ino_key, {"paths": [], "size": st.st_size,
                                                        "mtime": st.st_mtime, "ext": ext})
                        g["paths"].append(path)
                    except OSError as exc:
                        raise ScanSourceError(f"读取模型文件身份失败 {e.path}：{exc}") from exc
                files_rows.append((path, dirpath, e.name, ext, st.st_size, st.st_mtime,
                                   category, mtype, ino_key))
                size_acc += st.st_size
                f_acc += 1
                count[0] += 1
                if count[0] % 20000 == 0:
                    report(f"已扫描 {count[0]} 个文件…")
        dirs_agg[dirpath] = [size_acc, f_acc, d_acc]

    report("开始扫描目录树…")
    t0 = time.time()
    for r in roots:
        visit(r, 0)

    report(f"目录树完成：{count[0]} 文件 / {len(dirs_agg)} 目录（{time.time()-t0:.0f}s），写入数据库…")
    dirs_rows = []
    for p, (s, f, d) in dirs_agg.items():
        parent = os.path.dirname(p)
        depth = p.rstrip("\\").count("\\")
        dirs_rows.append((p, parent, os.path.basename(p) or p, depth, s, f, d, 0))
    dirs_rows.extend(dirs_rows_ignored)
    db.replace_scan_tables(dirs_rows, files_rows)
    root_paths = roots
    dirs_agg_total = sum(dirs_agg.get(rp, [0, 0, 0])[0] for rp in root_paths)
    unique_size = dirs_agg_total - (model_path_bytes[0] - model_unique_bytes[0])
    db.set_meta("unique_size", str(unique_size))
    report("文件清单已入库，构建模型库…")
    return {"file_count": count[0], "dir_count": len(dirs_agg),
            "unique_size": unique_size, "model_groups": groups}


# ---------------- 模型库构建 ----------------

def build_models(db, cfg, scan_result, progress_cb=None):
    """导入 codex Catalogs + 现场扫描补充未编目模型。"""
    stats = {"catalog": 0, "filesystem": 0, "missing": 0}
    groups = scan_result["model_groups"]
    known_paths = set()
    catalog_identities = set()

    def report(msg):
        if progress_cb:
            progress_cb(msg)

    def norm_path(p):
        if not p:
            return None
        try:
            return os.path.realpath(p)
        except Exception:
            return p

    # ---- 1. Catalogs: models.json + loras.csv + base_models.csv ----
    cat_dir = cfg.get("catalog_dir")
    entries = []
    csv_extra = {}
    if cat_dir and os.path.isfile(os.path.join(cat_dir, "models.json")):
        try:
            with open(os.path.join(cat_dir, "models.json"), encoding="utf-8") as f:
                data = json.load(f)
            entries = data.get("models") or []
            report(f"读取目录清单 models.json：{len(entries)} 条")
        except Exception as e:
            report(f"models.json 解析失败：{e}")
        for csv_name in ("loras.csv", "base_models.csv"):
            p = os.path.join(cat_dir, csv_name)
            if os.path.exists(p):
                try:
                    with open(p, encoding="utf-8-sig") as f:
                        for row in csv.DictReader(f):
                            csv_extra[row.get("id")] = row
                except Exception:
                    pass

    for ent in entries:
        canon = norm_path(ent.get("canonical_path") or ent.get("old_path"))
        if not canon:
            continue
        mtype = CATEGORY_MAP.get(ent.get("category"), ent.get("category") or None)
        extra = csv_extra.get(ent.get("id"), {})
        md = ent.get("metadata")
        meta_hdr = {k: str(v) for k, v in list(md.items())[:40]} if isinstance(md, dict) and md else {}
        exists = os.path.exists(canon)
        if not exists:
            stats["missing"] += 1
        filename = ent.get("filename") or os.path.basename(canon)
        alts = []
        for p in [norm_path(ent.get("runtime_path")), norm_path(ent.get("old_path"))]:
            if p and p != canon and p not in alts:
                alts.append(p)
        row = {
            "path": canon,
            "filename": filename,
            "norm_name": filename.lower(),
            "ext": os.path.splitext(canon)[1].lower(),
            "mtype": mtype or meta.model_type(canon) or "Unknown",
            "family": ent.get("family") or None,
            "family_conf": ent.get("family_confidence") or None,
            "scope": ent.get("scope") or "central",
            "size": ent.get("bytes"),
            "mtime": (ent.get("mtime_ns") or 0) / 1e9 or None,
            "inode": str(ent.get("inode") or ""),
            "alt_paths": json.dumps(alts, ensure_ascii=False),
            "legacy_uid": ent.get("id"),
            "header_meta": json.dumps(meta_hdr, ensure_ascii=False) if meta_hdr else None,
            "trigger_words": _join_trigger(ent.get("trigger_candidates"))
                             or meta.extract_trigger_words(meta_hdr) or None,
            "training_base": extra.get("training_base") or meta_hdr.get("ss_sd_model_name") or None,
            "lrank": _f(extra.get("rank") or meta_hdr.get("ss_network_dim")),
            "lalpha": _f(extra.get("alpha") or meta_hdr.get("ss_network_alpha")),
            "method": extra.get("method") or ent.get("method") or None,
            "missing": 0 if exists else 1,
            "update_state": "unchecked",
        }
        db.upsert_model(row)
        known_paths.add(canon.lower())
        identity = classification.file_identity(canon)
        if identity:
            catalog_identities.add(identity)
        stats["catalog"] += 1
    report(f"目录清单导入完成：{stats['catalog']} 条（文件缺失 {stats['missing']}）")

    # ---- 2. 现场扫描补充（未编目的模型文件，如新下载）----
    for _ino, g in groups.items():
        paths = g["paths"]
        primary = sorted(paths, key=_pref)[0]
        if primary.lower() in known_paths or classification.file_identity(primary) in catalog_identities:
            continue
        known_paths.add(primary.lower())
        db.upsert_model(_model_row_from_fs(primary, g, paths))
        stats["filesystem"] += 1
    report(f"现场补充新模型：{stats['filesystem']} 个")

    # ---- 3. Preserve personal records when scan roots or compatibility paths change. ----
    # A path absent from this scan is not proof the model or its annotations can
    # be deleted. Keep the row and mark it unavailable until a later scan finds
    # it again. Canonical matching also retains live legacy junction aliases.
    indexed_paths = {classification.path_key(os.path.realpath(row['path']))
                     for row in db.query("SELECT path FROM files WHERE category='model'")}
    unavailable = []
    available = []
    for row in db.query("SELECT path FROM models WHERE legacy_uid IS NULL"):
        canonical = classification.path_key(os.path.realpath(row['path']))
        (available if canonical in indexed_paths and os.path.isfile(row['path']) else unavailable).append((row['path'],))
    with db.lock:
        db.conn.executemany("UPDATE models SET missing=1 WHERE path=?", unavailable)
        db.conn.executemany("UPDATE models SET missing=0 WHERE path=?", available)
        stats["pruned"] = 0
        stats["unavailable_preserved"] = len(unavailable)
        db.conn.commit()
    if unavailable:
        report(f"本次扫描未覆盖的模型记录已保留：{len(unavailable)} 个，评分、备注与来源不删除")
    db.commit()
    return stats


def _f(v):
    try:
        return float(v) if v not in (None, "") else None
    except (TypeError, ValueError):
        return None


def _join_trigger(cands) -> str:
    """trigger_candidates 元素可能是 str / dict（如 {'word':..,'score':..}）。"""
    out = []
    for c in cands or []:
        if isinstance(c, dict):
            c = c.get("word") or c.get("name") or c.get("text") or json.dumps(c, ensure_ascii=False)
        if c:
            out.append(str(c))
    return ", ".join(out)[:300]


def _model_row_from_fs(primary, g, all_paths):
    filename = os.path.basename(primary)
    ext = os.path.splitext(filename)[1].lower()
    parent = os.path.basename(os.path.dirname(primary))
    _category, mtype = meta.classify_file(ext, parent)
    mtype = mtype or meta.model_type(primary)
    hdr_meta, _tensor_count = (None, 0)
    raw_meta = None
    if ext == ".safetensors":
        raw_meta, _tensor_count = meta.read_safetensors_header(primary)
        hdr_meta = meta.header_summary(raw_meta or {})
        if not mtype:
            arch = (raw_meta or {}).get("modelspec.architecture", "")
            if arch:
                mtype = "LoRA" if "lora" in arch.lower() else "Checkpoint"
    family = (hdr_meta or {}).get("ss_base_model_version")
    if mtype == "LLM":
        family = meta.llm_family(filename)
    return {
        "path": primary,
        "filename": filename,
        "norm_name": filename.lower(),
        "ext": ext,
        "mtype": mtype or "Unknown",
        "family": family,
        "scope": classification.scope_for(primary),
        "size": g["size"],
        "mtime": g["mtime"],
        "inode": classification.file_identity(primary),
        "alt_paths": json.dumps([p for p in all_paths if p != primary], ensure_ascii=False),
        "header_meta": json.dumps(hdr_meta, ensure_ascii=False) if hdr_meta else None,
        "trigger_words": meta.extract_trigger_words(raw_meta or {}),
        "training_base": (hdr_meta or {}).get("ss_base_model_version"),
        "method": (hdr_meta or {}).get("ss_network_module"),
        "missing": 0,
        "update_state": "unchecked",
    }
